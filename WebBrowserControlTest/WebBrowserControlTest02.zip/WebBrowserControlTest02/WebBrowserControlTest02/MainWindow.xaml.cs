﻿using System;
using System.Windows;
using Microsoft.Web.WebView2.Core;

namespace WebBrowserControlTest02
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Attach an event handler for when the WebView2 control is initialized
            webView.CoreWebView2InitializationCompleted += WebView_CoreWebView2InitializationCompleted;

            // Set the initial source (you can set it dynamically later if needed)
            webView.Source = new Uri("https://gsgate.gurusofttech.com/cloud51/PRDG11EOSV03WD/PRDG11EOSV03WB_TMS/WTR8503R1V1?ID=PEXPORTAL");
        }

        private void WebView_CoreWebView2InitializationCompleted(object sender, CoreWebView2InitializationCompletedEventArgs e)
        {
            // Handle the CoreWebView2 initialization completed event if needed
            // This is a good place to execute additional code after the WebView2 control is initialized
        }
    }
}
