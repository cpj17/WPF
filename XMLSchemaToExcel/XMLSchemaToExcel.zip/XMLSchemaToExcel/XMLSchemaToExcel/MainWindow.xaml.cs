﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.Win32;

namespace XMLSchemaToExcel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// Code By CPJ
    public partial class MainWindow : Window
    {
        //Code By CPJ (begins)
        string stringOutputPath = "Data/Output/";
        public MainWindow()
        {
            InitializeComponent();

            double screenWidth = System.Windows.SystemParameters.PrimaryScreenWidth;
            double screenHeight = System.Windows.SystemParameters.PrimaryScreenHeight;
            double windowWidth = this.Width;
            double windowHeight = this.Height;
            this.Left = (screenWidth / 2) - (windowWidth / 2);
            this.Top = (screenHeight / 2) - (windowHeight / 2);

            if (!Directory.Exists(stringOutputPath))
                Directory.CreateDirectory(stringOutputPath);
        }

        #region Users
        private void btnUser_Click(object sender, RoutedEventArgs e)
        {
            User(false);
        }
        private DataTable User(bool boolAll)
        {
            DataSet? objDataSetInput = null;
            DataSet? objDataSetConfig = null;
            DataSet? objDataSetFinal = null;
            string? stringTableName = string.Empty;
            string? stringExportAllColumn = string.Empty;
            DataTable? objDataTableTemp = null;
            try
            {
                objDataSetInput = new DataSet();
                objDataSetConfig = new DataSet();
                objDataSetFinal = new DataSet();
                objDataTableTemp = new DataTable();

                objDataSetInput.ReadXml("Data/Input/users.xml", XmlReadMode.Auto);
                objDataSetConfig.ReadXml("Data/Config/UserConfig.xml", XmlReadMode.Auto);

                stringTableName = objDataSetConfig.Tables["t1"].Rows[0]["table_name"].ToString();
                stringExportAllColumn = objDataSetConfig.Tables["t1"].Rows[0]["export_all_Col_flag"].ToString().ToUpper();

                objDataTableTemp = GetTable(objDataSetInput, stringTableName, objDataSetConfig, stringExportAllColumn);
                if (objDataTableTemp != null && objDataTableTemp.Rows.Count > 0)
                {
                    objDataSetFinal.Tables.Add(objDataTableTemp);

                    if (!boolAll)
                        ExcelSavePrompt(objDataSetFinal);
                    return objDataTableTemp;
                }
                else
                {
                    ShowMessage("INFO", "btnUser_Click : Returned Table is Null or Row count is Zero");
                }
            }
            catch (Exception objException)
            {
                MessageBox.Show(objException.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return objDataTableTemp;
        }
        #endregion

        #region UserGroup
        private void btnUserGroup_Click(object sender, RoutedEventArgs e)
        {
            UserGroup(false);
        }
        private DataTable UserGroup(bool boolAll)
        {
            DataSet? objDataSetInput = null;
            DataSet? objDataSetConfig = null;
            DataSet? objDataSetFinal = null;
            string? stringTableName = string.Empty;
            string? stringExportAllColumn = string.Empty;
            DataTable? objDataTableTemp = null;
            try
            {
                objDataSetInput = new DataSet();
                objDataSetConfig = new DataSet();
                objDataSetFinal = new DataSet();
                objDataTableTemp = new DataTable();

                objDataSetInput.ReadXml("Data/Input/user_groups.xml", XmlReadMode.Auto);
                objDataSetConfig.ReadXml("Data/Config/UserGroupConfig.xml", XmlReadMode.Auto);

                stringTableName = objDataSetConfig.Tables["t1"].Rows[0]["table_name"].ToString();
                stringExportAllColumn = objDataSetConfig.Tables["t1"].Rows[0]["export_all_Col_flag"].ToString().ToUpper();

                objDataTableTemp = GetTable(objDataSetInput, stringTableName, objDataSetConfig, stringExportAllColumn);
                if (objDataTableTemp != null && objDataTableTemp.Rows.Count > 0)
                {
                    objDataSetFinal.Tables.Add(objDataTableTemp);

                    if (!boolAll)
                        ExcelSavePrompt(objDataSetFinal);
                    return objDataTableTemp;
                }
                else
                {
                    ShowMessage("INFO", "btnUserGroup_Click : Returned Table is Null or Row count is Zero");
                }
            }
            catch (Exception objException)
            {
                MessageBox.Show(objException.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return objDataTableTemp;
        }
        #endregion

        #region SystemAccessPolicy
        private void btnSystemAccessPolicy_Click(object sender, RoutedEventArgs e)
        {
            SystemAccessPolicy(false);
        }
        private DataTable SystemAccessPolicy(bool boolAll)
        {
            DataSet? objDataSetInput = null;
            DataSet? objDataSetConfig = null;
            DataSet? objDataSetFinal = null;
            string? stringTableName = string.Empty;
            string? stringExportAllColumn = string.Empty;
            DataTable? objDataTableTemp = null;
            try
            {
                objDataSetInput = new DataSet();
                objDataSetConfig = new DataSet();
                objDataSetFinal = new DataSet();
                objDataTableTemp = new DataTable();

                objDataSetInput.ReadXml("Data/Input/system_access_policies.xml", XmlReadMode.Auto);
                objDataSetConfig.ReadXml("Data/Config/SystemAccessPolicyConfig.xml", XmlReadMode.Auto);

                stringTableName = objDataSetConfig.Tables["t1"].Rows[0]["table_name"].ToString();
                stringExportAllColumn = objDataSetConfig.Tables["t1"].Rows[0]["export_all_Col_flag"].ToString().ToUpper();

                objDataTableTemp = GetTable(objDataSetInput, stringTableName, objDataSetConfig, stringExportAllColumn);
                if (objDataTableTemp != null && objDataTableTemp.Rows.Count > 0)
                {
                    objDataSetFinal.Tables.Add(objDataTableTemp);

                    if (!boolAll)
                        ExcelSavePrompt(objDataSetFinal);
                    return objDataTableTemp;
                }
                else
                {
                    ShowMessage("INFO", "btnSystemAccessPolicy_Click : Returned Table is Null or Row count is Zero");
                }
            }
            catch (Exception objException)
            {
                MessageBox.Show(objException.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return objDataTableTemp;
        }
        #endregion

        #region Application Access Policy
        private void btnApplicationAccessPolicy_Click(object sender, RoutedEventArgs e)
        {
            ApplicationAccessPolicy(false);
        }
        private DataTable ApplicationAccessPolicy(bool boolAll)
        {
            DataSet? objDataSetInput = null;
            DataSet? objDataSetConfig = null;
            DataSet? objDataSetFinal = null;
            string? stringTableName = string.Empty;
            string? stringExportAllColumn = string.Empty;
            DataTable? objDataTableTemp = null;
            try
            {
                objDataSetInput = new DataSet();
                objDataSetConfig = new DataSet();
                objDataSetFinal = new DataSet();
                objDataTableTemp = new DataTable();

                objDataSetInput.ReadXml("Data/Input/application_access_policies.xml", XmlReadMode.Auto);
                objDataSetConfig.ReadXml("Data/Config/ApplicationAccessPolicyConfig.xml", XmlReadMode.Auto);

                stringTableName = objDataSetConfig.Tables["t1"].Rows[0]["table_name"].ToString();
                stringExportAllColumn = objDataSetConfig.Tables["t1"].Rows[0]["export_all_Col_flag"].ToString().ToUpper();

                objDataTableTemp = GetTable(objDataSetInput, stringTableName, objDataSetConfig, stringExportAllColumn);
                if (objDataTableTemp != null && objDataTableTemp.Rows.Count > 0)
                {
                    objDataSetFinal.Tables.Add(objDataTableTemp);

                    if (!boolAll)
                        ExcelSavePrompt(objDataSetFinal);
                    return objDataTableTemp;
                }
                else
                {
                    ShowMessage("INFO", "btnApplicationAccessPolicy_Click : Returned Table is Null or Row count is Zero");
                }
            }
            catch (Exception objException)
            {
                MessageBox.Show(objException.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return objDataTableTemp;
        }
        #endregion

        #region BU Access Policy
        private void btnBUAccessPolicy_Click(object sender, RoutedEventArgs e)
        {
            BUAccessPolicy(false);
        }
        private DataTable BUAccessPolicy(bool boolAll)
        {
            DataSet? objDataSetInput = null;
            DataSet? objDataSetConfig = null;
            DataSet? objDataSetFinal = null;
            string? stringTableName = string.Empty;
            string? stringExportAllColumn = string.Empty;
            DataTable? objDataTableTemp = null;
            try
            {
                objDataSetInput = new DataSet();
                objDataSetConfig = new DataSet();
                objDataSetFinal = new DataSet();
                objDataTableTemp = new DataTable();

                objDataSetInput.ReadXml("Data/Input/bu_data_access_policies.xml", XmlReadMode.Auto);
                objDataSetConfig.ReadXml("Data/Config/BUAccessPolicyConfig.xml", XmlReadMode.Auto);

                stringTableName = objDataSetConfig.Tables["t1"].Rows[0]["table_name"].ToString();
                stringExportAllColumn = objDataSetConfig.Tables["t1"].Rows[0]["export_all_Col_flag"].ToString().ToUpper();

                objDataTableTemp = GetTable(objDataSetInput, stringTableName, objDataSetConfig, stringExportAllColumn);
                if (objDataTableTemp != null && objDataTableTemp.Rows.Count > 0)
                {
                    objDataSetFinal.Tables.Add(objDataTableTemp);

                    if (!boolAll)
                        ExcelSavePrompt(objDataSetFinal);
                    return objDataTableTemp;
                }
                else
                {
                    ShowMessage("INFO", "btnApplicationAccessPolicy_Click : Returned Table is Null or Row count is Zero");
                }
            }
            catch (Exception objException)
            {
                MessageBox.Show(objException.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return objDataTableTemp;
        }
        #endregion

        #region DC Access Policy
        private void btnDCAccessPolicy_Click(object sender, RoutedEventArgs e)
        {
            DCAccessPolicy(false);
        }
        private DataTable DCAccessPolicy(bool boolAll)
        {
            DataSet? objDataSetInput = null;
            DataSet? objDataSetConfig = null;
            DataSet? objDataSetFinal = null;
            string? stringTableName = string.Empty;
            string? stringExportAllColumn = string.Empty;
            DataTable? objDataTableTemp = null;
            try
            {
                objDataSetInput = new DataSet();
                objDataSetConfig = new DataSet();
                objDataSetFinal = new DataSet();
                objDataTableTemp = new DataTable();

                objDataSetInput.ReadXml("Data/Input/dc_data_access_policies.xml", XmlReadMode.Auto);
                objDataSetConfig.ReadXml("Data/Config/DCAccessPolicyConfig.xml", XmlReadMode.Auto);

                stringTableName = objDataSetConfig.Tables["t1"].Rows[0]["table_name"].ToString();
                stringExportAllColumn = objDataSetConfig.Tables["t1"].Rows[0]["export_all_Col_flag"].ToString().ToUpper();

                objDataTableTemp = GetTable(objDataSetInput, stringTableName, objDataSetConfig, stringExportAllColumn);
                if (objDataTableTemp != null && objDataTableTemp.Rows.Count > 0)
                {
                    objDataSetFinal.Tables.Add(objDataTableTemp);

                    if (!boolAll)
                        ExcelSavePrompt(objDataSetFinal);
                    return objDataTableTemp;
                }
                else
                {
                    ShowMessage("INFO", "btnApplicationAccessPolicy_Click : Returned Table is Null or Row count is Zero");
                }
            }
            catch (Exception objException)
            {
                MessageBox.Show(objException.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return objDataTableTemp;
        }
        #endregion

        #region Combined Data
        private void btnCombinedData_Click(object sender, RoutedEventArgs e)
        {
            CombineData();
        }
        private void CombineData()
        {
            DataSet objDataSetUser = new DataSet();
            DataSet objDataSetUserGroup = new DataSet();
            DataSet objDataSetDCAccessPolicy = new DataSet();
            DataSet objDataSetBUAccessPolicy = new DataSet();
            DataSet objDataSetApplicationAccessPolicy = new DataSet();
            DataSet objDataSetConfig = new DataSet();
            DataSet objDataSetFinal = new DataSet();
            DataTable objDataTable = new DataTable();
            DataTable objDataTableTemp = new DataTable();

            string stringTableName = "";
            try
            {
                objDataTable.Columns.Add("user_id");
                objDataTable.Columns.Add("group_id");
                objDataTable.Columns.Add("group_name");
                objDataTable.Columns.Add("dc_id");
                objDataTable.Columns.Add("be_id");
                objDataTable.Columns.Add("app_id");
                objDataTable.Columns.Add("app_type_id");

                //Config
                objDataSetConfig.ReadXml("Data/Config/CombineDataConfig.xml", XmlReadMode.Auto);

                objDataSetUser.ReadXml("Data/Input/users.xml", XmlReadMode.Auto);
                objDataSetUserGroup.ReadXml("Data/Input/user_groups.xml", XmlReadMode.Auto);
                objDataSetDCAccessPolicy.ReadXml("Data/Input/dc_data_access_policies.xml", XmlReadMode.Auto);
                objDataSetBUAccessPolicy.ReadXml("Data/Input/bu_data_access_policies.xml", XmlReadMode.Auto);
                objDataSetApplicationAccessPolicy.ReadXml("Data/Input/application_access_policies.xml", XmlReadMode.Auto);

                foreach (DataRow objDataRowUser in objDataSetUser.Tables[0].Rows)
                {
                    string? stringUserID = objDataRowUser["user_id"].ToString();

                    //User Groups
                    string stringUserGroupID = "";
                    string stringUserGroupName = "";
                    DataRow[] objDataRowCollnUserGroup = objDataSetUserGroup.Tables[0].Select("user_id = '" + stringUserID + "'");
                    foreach (DataRow row in objDataRowCollnUserGroup)
                    {
                        stringUserGroupID += row["group_id"].ToString() + ",";
                        stringUserGroupName += row["group_name"].ToString() + ",";
                    }

                    //DC Access Policy
                    string stringDCID = "";
                    DataRow[] objDataRowCollnDC = objDataSetDCAccessPolicy.Tables[0].Select("user_id = '" + stringUserID + "'");
                    foreach (DataRow row in objDataRowCollnDC)
                    {
                        stringDCID += row["dc_id"].ToString() + ",";
                    }

                    //BU Access Policy
                    string stringBUID = "";
                    DataRow[] objDataRowCollnBU = objDataSetBUAccessPolicy.Tables[0].Select("user_id = '" + stringUserID + "'");
                    foreach (DataRow row in objDataRowCollnBU)
                    {
                        stringBUID += row["be_id"].ToString() + ",";
                    }

                    //Application Access Policy
                    string stringAppID = "";
                    string stringAppTypeID = "";
                    DataRow[] objDataRowCollnApp = objDataSetApplicationAccessPolicy.Tables[0].Select("user_id = '" + stringUserID + "'");
                    foreach (DataRow row in objDataRowCollnApp)
                    {
                        stringAppID += row["app_id"].ToString() + ",";
                        stringAppTypeID += row["app_type_id"].ToString() + ",";
                    }

                    //Assign Values
                    DataRow objDataRow = objDataTable.NewRow();
                    objDataRow["user_id"] = objDataRowUser["user_id"].ToString();
                    objDataRow["group_id"] = stringUserGroupID.Trim(',');
                    objDataRow["group_name"] = stringUserGroupName.Trim(',');
                    objDataRow["dc_id"] = stringDCID.Trim(',');
                    objDataRow["be_id"] = stringBUID.Trim(',');
                    objDataRow["app_id"] = stringAppID.Trim(',');
                    objDataRow["app_type_id"] = stringAppTypeID.Trim(',');
                    objDataTable.Rows.Add(objDataRow);
                }
                
                objDataSetUser.Tables[0].PrimaryKey = new DataColumn[] { objDataSetUser.Tables[0].Columns["user_id"] };
                objDataSetUser.Tables[0].Merge(objDataTable);

                stringTableName = objDataSetConfig.Tables["t1"].Rows[0]["table_name"].ToString();
                objDataTableTemp = GetTable(objDataSetUser, stringTableName, objDataSetConfig, "N");
                objDataSetFinal.Tables.Add(objDataTableTemp);

                ExcelSavePrompt(objDataSetFinal);
            }
            catch (Exception objException)
            {
                MessageBox.Show(objException.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        #endregion

        private DataTable GetTable(DataSet objDataSetInput, string stringTableName, DataSet objDataSetConfig, string stringExportAllColumn)
        {
            DataTable? objDataTableConfig = null;
            DataTable? objDataTableResult = null;
            try
            {
                objDataTableConfig = new DataTable();
                objDataTableResult = new DataTable();

                if (stringExportAllColumn.ToUpper() == "N")
                {
                    objDataTableConfig = objDataSetConfig.Tables["t2"].Select("", "list_view_position asc").CopyToDataTable();
                    for (int i = 0; i < objDataTableConfig.Rows.Count; i++)
                    {
                        string stringColumnName = objDataTableConfig.Rows[i]["column_name"].ToString();
                        if (!objDataTableResult.Columns.Contains(stringColumnName))
                            objDataTableResult.Columns.Add(stringColumnName);
                    }

                    objDataTableResult.Merge(objDataSetInput.Tables[stringTableName], true, MissingSchemaAction.Ignore);

                    for (int i = 0; i < objDataTableConfig.Rows.Count; i++)
                    {
                        string stringColumnName = objDataTableConfig.Rows[i]["column_name"].ToString();
                        string stringDisplayName = objDataTableConfig.Rows[i]["display_name"].ToString();

                        objDataTableResult.Columns[stringColumnName].ColumnName = stringDisplayName;
                    }

                    objDataTableResult.TableName = stringTableName;
                    objDataTableResult.WriteXml(stringOutputPath + stringTableName + "_Out_" + DateTime.Now.ToString("hhmmssfff") + ".xml");
                }
                else
                {
                    objDataTableResult = objDataSetInput.Tables[stringTableName].Copy();
                }
                return objDataTableResult;
            }
            catch (Exception objException)
            {
                MessageBox.Show(objException.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            return objDataTableResult;
        }

        private void ShowMessage(string stringType, string stringMsg)
        {
            try
            {
                if (stringType.ToUpper() == "INFO")
                {
                    MessageBox.Show(stringMsg, "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                if (stringType.ToUpper() == "ERROR")
                {
                    MessageBox.Show(stringMsg, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception objException)
            {
                MessageBox.Show(objException.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ExcelSavePrompt(DataSet objDataSetInput)
        {
            try
            {
                SaveFileDialog objSaveFileDialog = new SaveFileDialog();
                objSaveFileDialog.Filter = "Excel Workbook|*.xlsx";
                if (objSaveFileDialog.ShowDialog() == true)
                {
                    using (XLWorkbook objWorkBook = new XLWorkbook())
                    {
                        objWorkBook.AddWorksheet(objDataSetInput);
                        objWorkBook.SaveAs(objSaveFileDialog.FileName);
                    }

                    ShowMessage("INFO", "Exported Successfully");
                }
            }
            catch (Exception objException)
            {
                MessageBox.Show(objException.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnAll_Click(object sender, RoutedEventArgs e)
        {
            ExportAll();
        }

        private void ExportAll()
        {
            DataSet? objDataSetFinal = null;
            try
            {
                objDataSetFinal = new DataSet();
                objDataSetFinal.Tables.Add(User(true).Copy());
                objDataSetFinal.Tables.Add(UserGroup(true).Copy());
                objDataSetFinal.Tables.Add(SystemAccessPolicy(true).Copy());
                objDataSetFinal.Tables.Add(ApplicationAccessPolicy(true).Copy());
                objDataSetFinal.Tables.Add(BUAccessPolicy(true).Copy());
                objDataSetFinal.Tables.Add(DCAccessPolicy(true).Copy());

                objDataSetFinal.WriteXml(stringOutputPath + "All_Out_" + DateTime.Now.ToString("hhmmssfff") + ".xml");
                ExcelSavePrompt(objDataSetFinal);
            }
            catch (Exception objException)
            {
                MessageBox.Show(objException.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        //Code By CPJ (ends)
    }
}
